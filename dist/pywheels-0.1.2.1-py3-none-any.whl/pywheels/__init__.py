from .i18n import setup_translate_language


__all__ = [
]


setup_translate_language()