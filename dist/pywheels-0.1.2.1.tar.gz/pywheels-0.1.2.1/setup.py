from setuptools import setup
from setuptools import find_packages


setup(
    name = 'pywheels',
    version = '0.1.2.1',
    packages = find_packages(),
    description = 'add i18n support for pywheels',
    author = 'parkcai',
    author_email = 'sun_retailer@163.com',
    url = 'https://github.com/parkcai/pywheels',
)