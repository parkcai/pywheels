from setuptools import setup
from setuptools import find_packages


setup(
    name = 'pywheels',
    version = '0.1.1',
    packages = find_packages(),
    description = 'improve print_helloworld',
    author = 'parkcai',
    author_email = 'sun_retailer@163.com',
    url = 'https://github.com/parkcai/pywheels',
)