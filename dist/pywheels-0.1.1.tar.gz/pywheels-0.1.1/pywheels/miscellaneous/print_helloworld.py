__all__ = [
    "print_helloworld",
]


def print_helloworld(
)-> None:
    
    print("Hello, World!")